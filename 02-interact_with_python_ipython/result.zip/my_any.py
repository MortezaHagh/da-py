# coding: utf-8
def my_any(x):
    for xx in x:
        if xx:
            return True
    return False
